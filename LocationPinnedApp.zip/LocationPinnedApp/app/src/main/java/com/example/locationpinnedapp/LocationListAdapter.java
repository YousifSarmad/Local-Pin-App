package com.example.locationpinnedapp;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class LocationListAdapter extends RecyclerView.Adapter<LocationListAdapter.LocationViewHolder> {
    private Context context;
    private List<Location> locationList;

    public LocationListAdapter(Context context, List<Location> locationList) {
        this.context = context;
        this.locationList = locationList;
    }

    @Override
    public LocationViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.location_list_item, parent, false);
        return new LocationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(LocationViewHolder holder, int position) {
        Location location = locationList.get(position);

        holder.longitudeTextView.setText(String.valueOf(location.getLongitude()));
        holder.latitudeTextView.setText(String.valueOf(location.getLatitude()));
        holder.addressTextView.setText(location.getAddress());
    }

    @Override
    public int getItemCount() {
        return locationList.size();
    }

    public class LocationViewHolder extends RecyclerView.ViewHolder {
        TextView longitudeTextView;
        TextView latitudeTextView;
        TextView addressTextView;

        public LocationViewHolder(View itemView) {
            super(itemView);

            longitudeTextView = itemView.findViewById(R.id.longitudeTextView);
            latitudeTextView = itemView.findViewById(R.id.latitudeTextView);
            addressTextView = itemView.findViewById(R.id.addressTextView);
        }
    }
}
