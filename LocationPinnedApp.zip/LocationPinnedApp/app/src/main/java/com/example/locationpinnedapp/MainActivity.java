package com.example.locationpinnedapp;


import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private LocationDataSource locationDataSource;
    private Button addButton;
    private Button deleteButton;
    private Button updateButton;
    private Button queryButton;
    private EditText addressEditText;
    private TextView latitudeTextView;
    private TextView longitudeTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationDataSource = new LocationDataSource(this);
        locationDataSource.open();

        addButton = findViewById(R.id.btnAddLocation);
        deleteButton = findViewById(R.id.btnDeleteLocation);
        updateButton = findViewById(R.id.btnUpdateLocation);
        queryButton = findViewById(R.id.btnQueryLocation);
        addressEditText = findViewById(R.id.addressEditText);
        latitudeTextView = findViewById(R.id.latitudeTextView);
        longitudeTextView = findViewById(R.id.longitudeTextView);

        queryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String addressToQuery = addressEditText.getText().toString();
                Location location = locationDataSource.getLocationByAddress(addressToQuery);

                if (location != null) {
                    latitudeTextView.setText(String.valueOf(location.getLatitude()));
                    longitudeTextView.setText(String.valueOf(location.getLongitude()));
                } else {
                    showToast("Location not found in the database.");
                }
            }
        });

        Button tableButton = findViewById(R.id.tableButton);
        tableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, LocationListActivity.class);
                startActivity(intent);
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double latitude = 37.7749;
                double longitude = -122.4194;
                String address = "New Location Address";

                long locationId = locationDataSource.insertLocation(address, latitude, longitude);

                if (locationId != -1) {
                    showToast("Location added with ID: " + locationId);
                } else {
                    showToast("Failed to add location.");
                }
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String addressToDelete = addressEditText.getText().toString();
                int rowsDeleted = locationDataSource.deleteLocationByAddress(addressToDelete);

                if (rowsDeleted > 0) {
                    showToast(rowsDeleted + " location(s) deleted.");
                } else {
                    showToast("Location not found or deletion failed.");
                }
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String addressToUpdate = addressEditText.getText().toString();

                double newLatitude = 37.7750;
                double newLongitude = -122.4195;

                int rowsUpdated = locationDataSource.updateLocation(addressToUpdate, newLatitude, newLongitude);

                if (rowsUpdated > 0) {
                    showToast(rowsUpdated + " location(s) updated.");
                } else {
                    showToast("Location not found or update failed.");
                }
            }
        });
        readSampleCoordinates("sample_coordinates.txt");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        locationDataSource.close();
    }

    private void readSampleCoordinates(String filename) {
        try {
            InputStream inputStream = getAssets().open(filename);
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String latitudeStr = parts[0].trim();
                    String longitudeStr = parts[1].trim();

                    if (!latitudeStr.isEmpty() && !longitudeStr.isEmpty()) {
                        try {
                            double latitude = Double.parseDouble(latitudeStr);
                            double longitude = Double.parseDouble(longitudeStr);

                            String address = geocode(latitude, longitude);
                            long locationId = locationDataSource.insertLocation(address, latitude, longitude);

                            if (locationId != -1) {
                                showToast("Location added with ID: " + locationId);
                            } else {
                                showToast("Failed to add location.");
                            }
                        } catch (NumberFormatException e) {
                            showToast("Error parsing latitude or longitude as double: " + e.getMessage());
                        }
                    } else {
                        showToast("Latitude or longitude is empty in the file: " + line);
                    }
                } else {
                    showToast("Invalid format in the file: " + line);
                }
            }
            bufferedReader.close();
        } catch (IOException e) {
            showToast("Error reading sample coordinates from assets: " + e.getMessage());
            e.printStackTrace();
        }
    }



    private String geocode(double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(this);
        List<Address> addresses;

        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                StringBuilder addressBuilder = new StringBuilder();

                for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
                    addressBuilder.append(address.getAddressLine(i)).append(", ");
                }

                String fullAddress = addressBuilder.toString().trim();

                Log.d("Geocoded Address", fullAddress);

                return fullAddress;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "Address not found";
    }


    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
