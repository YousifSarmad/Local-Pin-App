package com.example.locationpinnedapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class LocationDataSource {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public LocationDataSource(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long insertLocation(String address, double latitude, double longitude) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ADDRESS, address);
        values.put(DatabaseHelper.COLUMN_LATITUDE, latitude);
        values.put(DatabaseHelper.COLUMN_LONGITUDE, longitude);

        return database.insert(DatabaseHelper.TABLE_LOCATIONS, null, values);
    }

    public Location getLocationByAddress(String address) {
        Cursor cursor = database.query(DatabaseHelper.TABLE_LOCATIONS, null,
                DatabaseHelper.COLUMN_ADDRESS + " = ?", new String[]{address}, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
            Location location = cursorToLocation(cursor);
            cursor.close();
            return location;
        } else {
            return null;
        }
    }
    public int deleteLocationByAddress(String address) {
        String whereClause = DatabaseHelper.COLUMN_ADDRESS + " = ?";
        String[] whereArgs = { address };

        return database.delete(DatabaseHelper.TABLE_LOCATIONS, whereClause, whereArgs);
    }

    public int updateLocation(String addressToUpdate, double newLatitude, double newLongitude) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_LATITUDE, newLatitude);
        values.put(DatabaseHelper.COLUMN_LONGITUDE, newLongitude);

        String whereClause = DatabaseHelper.COLUMN_ADDRESS + " = ?";
        String[] whereArgs = { addressToUpdate };

        return database.update(DatabaseHelper.TABLE_LOCATIONS, values, whereClause, whereArgs);
    }
    public List<Location> getAllLocations() {
        List<Location> locations = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE_LOCATIONS, null, null, null, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                Location location = cursorToLocation(cursor);
                locations.add(location);
                cursor.moveToNext();
            }
            cursor.close();
        }
        return locations;
    }
    private Location cursorToLocation(Cursor cursor) {
        Location location = new Location();
        location.setId(cursor.getLong(0));
        location.setAddress(cursor.getString(1));
        location.setLatitude(cursor.getDouble(2));
        location.setLongitude(cursor.getDouble(3));
        return location;
    }
}
