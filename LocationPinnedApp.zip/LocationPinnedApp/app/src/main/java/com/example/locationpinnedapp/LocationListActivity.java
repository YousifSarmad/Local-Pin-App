package com.example.locationpinnedapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class LocationListActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private LocationListAdapter locationListAdapter;
    private LocationDataSource locationDataSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_list);

        locationDataSource = new LocationDataSource(this);
        locationDataSource.open();

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        locationListAdapter = new LocationListAdapter(this, locationDataSource.getAllLocations());
        recyclerView.setAdapter(locationListAdapter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        locationDataSource.close();
    }
}
